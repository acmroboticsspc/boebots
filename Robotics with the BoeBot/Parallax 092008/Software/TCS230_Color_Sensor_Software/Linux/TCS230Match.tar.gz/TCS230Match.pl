#!usr/bin/perl

#############################################################################
#                                                                           #
# TCS230Match.pl Perl/Tk program for color matching using the TAOS/Parallax #
#                TCS230 Color Sensor Module Set. It requires the Perl/Tk    #
#                module ToggleButton.pm (included) as well as a running     #
#                BASIC Stamp program, TCS230Demo.BS2 and an available       #
#                serial port.                                               #
#                                                                           #
# Copyright (C) 2002, 2003  Bueno Systems, Inc.                             #
#                                                                           #
# Contact: Phil Pilgrim: author@buenosystems.com                            #
#                                                                           #
# This program is free software; you can redistribute it and/or modify      #
# it under the terms of the GNU General Public License as published by      #
# the Free Software Foundation; version 2 of the License.                   #
#                                                                           #
# This program is distributed in the hope that it will be useful,           #
# but WITHOUT ANY WARRANTY; without even the implied warranty of            #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             #
# GNU General Public License for more details.                              #
#                                                                           #
# You should have received a copy of the GNU General Public License         #
# along with this program; if not, write to the Free Software               #
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA #
#                                                                           #
#############################################################################

use strict;
use Device::SerialPort qw(:STAT);
use Tk;
use Tk::Canvas;
use Tk::Scale;
use Tk::DialogBox;
use Tk::ToggleButton;

#############################################################################
# Program scans all devices in this list for a running BASIC Stamp program. #
# Add to or delete from it as needed to accomodate your own devices.        #
#############################################################################
my @Devices = qw(/dev/ttyS0 /dev/ttyS1 /dev/ttyS2 /dev/ttyS3);

my @RGB = qw(#ff0000 #00ff00 #0000ff);
my (@CurrentWhite, @CurrentRGB, @CurrentRaw, @DefinedColor);
my ($stream, $lastRGB, $WBMode, $Selected, $PrevSelected, $Flash);

use constant CMD_RAW => 'Balanced';
use constant CMD_BAL => 'Raw';

my $mw = Tk::MainWindow->new(-title => 'TAOS/Parallax TCS230 Color Matching Host v1.2 (Linux)');
$mw->withdraw;

my $fraTop = $mw->Frame->pack(-side => 'top');
my $fraBot = $mw->Frame->pack(-side => 'top');

my $fraSwatchPanel = $fraTop->Frame(
	-height => 256,
	-width => 128,
)->pack(-side => 'left');

my $Message;
my $txtMsg = $fraSwatchPanel->Label(
	-background => 'BLACK',
	-foreground => 'YELLOW',
	-textvariable => \$Message,
	-relief => 'sunken',
	-borderwidth => 2
)->pack(-side => 'top', -expand => 1, -fill => 'x', -padx => 2, -pady => 2);

my $fraWB = $fraSwatchPanel->Frame()->pack(-side => 'top');

my @btnWB;
foreach (0, 1) {
	$btnWB[$_] = $fraWB->ToggleButton(
		-width => 8.5,
		-text => $_ ? 'Balanced' : 'Raw',
		-ontrigger => 'press',
		-latching => 1,
		-togglegroup => \@btnWB,
		-onbackground => 'CYAN',
		-onaltbackground => 'YELLOW',
		-onaltforeground => 'RED',
		-command => \&PressWB,
		-index => $_
	)->pack(-side => 'left');
}

$fraSwatchPanel->ToggleButton(
	-text => 'Do White Balance',
	-command => \&DoWhiteBalance
)->pack(-side => 'top', -expand => 1, -fill => 'x', -padx => 4, -pady => 2);

my $canBars = $fraSwatchPanel->Canvas(
	-background => 'BLACK',
	-width => 124,
	-height => 60,
	-relief => 'sunken',
	-borderwidth => 2
)->pack(-side => 'top', -pady => 2);

my (@canBar, @txtBar);
foreach (0..2) {
	$canBar[$_] = $canBars->createRectangle(
		0, $_ * 20 + 4, -128, $_ * 20 + 23,
		-fill => $RGB[$_]
	);
	$txtBar[$_] = $canBars->createText(
		65,$_ * 20 + 14, 
		-text => '',
		-font => 'Arial 11 bold',
		-fill => 'WHITE',
		-justify => 'right'
	)
}

my $fraSwatch = $fraSwatchPanel->Frame(
	-background => 'BLACK',
	-height => 45,
	-width => 128,
	-relief => 'sunken',
	-borderwidth => 2,
)->pack(-side => 'top');

my $CurrentGamma = 35;

$fraSwatchPanel->Scale(
	-orient => 'horizontal',
	-label => 'Gamma Correction',
	-length => 128,
	-width => 15,
	-sliderlength => 15,
	-from => 1,
	-to => 100,
	-troughcolor => 'BLACK',
	-variable => \$CurrentGamma,
	-command => \&SetGamma
)->pack(-side => 'top');

$fraSwatchPanel->Label(
	-text => '�2002 Bueno Systems, Inc.',
	-font => 'Arial 10 normal'
)->pack;

my $fraButtons = $fraTop->Frame(
	-width => 260,
	-height => 260
)->pack(-side => 'left');

my @lblColor;
foreach my $y (0..9) {
	foreach my $x (0..9) {
		my $i = $y * 10 + $x;
		$lblColor[$i] = $fraButtons->Label(
			-takefocus => 1,
			-relief => 'raised',
			-borderwidth => 1,
			-text => $i,
		)->place(-x => $x * 26, -y => $y * 26, -width => 26, -height => 26);
		$lblColor[$i]->bind('<Button-1>' => eval("sub {DefineColor($i, ".'@CurrentRGB)}'));
		$lblColor[$i]->bind('<Button-3>' => eval("sub {UndefineColor($i)}"));
	}
}

my $canDist = $fraBot->Canvas(
	-background => 'BLACK',
	-height => 210,
	-width => 390
)->pack;

my @txtDist;
foreach (0..99) {
	$txtDist[$_] = $canDist->createText(
		500, 0, 
		-text => $_, 
		-fill => 'WHITE',
		-font => 'Arial 9 bold',
		-justify => 'right'
	)
}

$mw->update;
$mw->deiconify;
$mw->raise;

my $Port;
foreach my $dev ((@Devices) x 2, undef) {
	unless (defined $dev) {
		$mw->messageBox(
			-title => 'Serial I/O Error',
			-message => 'Unable to locate a running TCS230 on any serial port.',
			-type => 'OK'
		);
		exit
	}
	$Message = "Scanning $dev.";
	$txtMsg->update;
	
	if ($Port = Device::SerialPort->new($dev, 1)) {
		$Port->databits(8);
		$Port->baudrate(9600);
		$Port->parity("none");
		$Port->stopbits(1);
		$Port->handshake("none");
		$Port->buffers(4096,4096);
		$Port->write_settings;
	} else {
		next
	}
	sleep 1;
	my $stream = $Port->input;
	last if $stream =~ m/R\d\d\d G\d\d\d B\d\d\d\r/;
	$Port->close;
	undef $Port;
}	
$Message = '';
my $UpdateID = $mw->repeat(50, \&Update);
$mw->repeat(250, \&FlashSelected);
$btnWB[0]->TurnOn;
MainLoop();

sub Update {
	my (@color, $nxt);
	$Port->error_msg(1);
	if (my $inp = $Port->input) {
		$stream .= $inp;
		while ($stream =~ m/(R\d\d\d G\d\d\d B\d\d\d)\r/osg) {
			$lastRGB = $1;
			$nxt = pos($stream);
		}
		$stream = substr($stream, $nxt) if defined $nxt;
		if ($lastRGB && defined $WBMode) {
			foreach my $i (0..2) {
				$color[$i] = substr($lastRGB, $i * 5 + 1, 3) + 0;
			}
			@CurrentRaw = @color;
			if ($WBMode eq CMD_BAL && defined @CurrentWhite) {
				@CurrentRGB = map {int($CurrentRaw[$_] * 255 / $CurrentWhite[$_])} (0 .. 2)
			} else {
				@CurrentRGB = @CurrentRaw
			}
			my $status = grep {$_ > 255} @CurrentRGB;
			$Message = $status ? 'Saturated' : '';
			@CurrentRGB = map {$_ > 255 ? 255 : $_} @CurrentRGB;
			foreach my $i (0..2) {
				$canBars->itemconfigure($txtBar[$i], -text => $CurrentRGB[$i]);
				$canBars->coords($canBar[$i], 0, $i * 20 + 4, $CurrentRGB[$i] / 2, $i * 20 + 23)
			}
			$fraSwatch->configure(-background => ScreenColor(@CurrentRGB));
			&BestMatch
		}
	}
}

sub SetGamma {
	foreach (grep defined, @DefinedColor) {
		my ($n, @rgb) = @$_;
		$lblColor[$n]->configure(-background => ScreenColor(@rgb))
	}
}

sub ScreenColor {
	return sprintf('#%2.2X%2.2X%2.2X', GammaCorrect(@_))
}

sub GammaCorrect {
	my $max = (sort {$b <=> $a} @_)[0];
	my $gammaf = ($max / 255) ** ($CurrentGamma / 100) * 255 / $max;
	return map {$gammaf * $_} @_
}

sub DefineColor {
	if ($WBMode eq CMD_RAW) {
		$mw->messageBox(-message => "Can't assign a raw color. Use 'Balanced' mode.", -type => 'ok')
	} else {
		my $no = shift;
		my @rgb = @_;
		$lblColor[$no]->configure(
			-relief => 'sunken',
			-background => ScreenColor(@rgb),
		);
		$DefinedColor[$no] = [$no, @rgb];
		&BestMatch
	}
}

sub UndefineColor {
	my $no = shift;
	$lblColor[$no]->configure(-relief => 'raised', -background => 'LIGHTGRAY');
	$canDist->coords($txtDist[$no], 500,0);
	undef $DefinedColor[$no];
	&BestMatch;
}

sub FlashSelected {
	if (defined $PrevSelected) {
		$lblColor[$PrevSelected]->configure(-foreground => 'BLACK');
	}
	if (defined $Selected) {
		$lblColor[$Selected]->configure(-foreground => $Flash ? 'BLACK' : 'YELLOW');
		$Flash = not $Flash;
	}
	$PrevSelected = $Selected
}

sub BestMatch {
	my $nBest;
	my $distBest = 1e38;
	my @Defined = grep defined, @DefinedColor;
	foreach (@Defined) {
		my ($n, @rgb) = @$_;
		my $distMax = 0;
		foreach my $i (0..2) {
			my $dist = abs($rgb[$i] - $CurrentRGB[$i]);
			$distMax = $dist if $dist > $distMax
		}
		$canDist->coords($txtDist[$n], $distMax * 2 + 10, $n * 2 + 10);
		if ($distMax < $distBest) {$nBest = $n; $distBest = $distMax}
	}
	return $Selected = $nBest
}

sub PressWB {
	my ($on, $i) = @_;
	if ($on) {
		if ($i && !defined @CurrentWhite) {
			print "*";
			$mw->messageBox(-message => '"White" is undefined. Do a white balance first.', -type => 'ok');
			$btnWB[0]->TurnOn;
			return
		}
		$WBMode = $i ? CMD_BAL : CMD_RAW
	}
}

sub DoWhiteBalance {
	my $on = shift;
	if ($on) {
		@CurrentWhite = @CurrentRaw;
		$btnWB[1]->TurnOn
	}
}

