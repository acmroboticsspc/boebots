This package consists of the following files:

ReadMe.txt         This file.
MatchDemo.pdf      Color match demo documentation.
TCS230Demo.bs2     BASIC Stamp program for the color match demo.
TCS230Match.pl     PC host program (Perl/Tk) for the color match demo.
ToggleButton.pm    ToggleButton (Perl/Tk) module.

To install, extract the files into any handy location. You must have Perl
and Perl/Tk installed to run the host program. The file ToggleButton.pm
should be moved or copied to the Perl library in the Tk directory.

To run, first load the program TCS230Demo.bs2 into the BASIC Stamp that
hosts the TCS230 color module. Then type:

perl TCS230Match.pl

Be sure to read the file MatchDemo.pdf for operational details.