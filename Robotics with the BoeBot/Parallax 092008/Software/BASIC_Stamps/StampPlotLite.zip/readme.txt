This zip of Stamp Plot Lite may used to install
the application from a single directory,
or it may be used to create install floppies.

To create floppies:
1. Unzip the files to a directory
2. On Floppy 1 place:
   setup.exe
   setup.lst
   StampP1.cab
3. On Floppy 2 place:
   StampP2.cab
