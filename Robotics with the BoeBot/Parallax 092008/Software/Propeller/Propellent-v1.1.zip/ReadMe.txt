Welcome to the Propellent Library and Executable software for the Propeller microcontroller.


WHERE TO FIND INFORMATION

Documentation on this product is contained in the "Propellent Library.pdf" and "Propellent Executable.pdf" files.

Please visit the Parallax web site periodically to find updated software and documentation.

  http://www.parallax.com/propeller



SYSTEM REQUIREMENTS

Windows 2000 or later
The recommended processor for the Operating System
The recommended RAM for the Operating System
20 MB Free Hard Drive Space
24-bit, or better, SVGA video card
1 Available USB port or COM port





WHAT'S NEW
----------

Version 1.1 [Library and Executable]

---General---

Updated embedded Propeller Executable Syntax document.

Enhanced serial routines to support FTDI VCP Driver v2.4.6 to avoid a possible "Write Error on COMx" message.





Version 1.0 [Library and Executable] - Initial release.